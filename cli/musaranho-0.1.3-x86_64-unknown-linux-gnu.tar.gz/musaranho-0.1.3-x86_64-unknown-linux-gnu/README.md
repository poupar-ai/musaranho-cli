# Musaranho 0.1.3 — prévia de teste

Executável Linux x86_64; requer glibc 2.34 ou superior, libgcc_s.so.1 e bibliotecas padrão do sistema. Não exige Rust, Python ou GPU para testar o servidor. Sem modelo de inferência nesta versão.

```bash
./musaranho --version
./musaranho token create --name teste
./musaranho serve
```

Guarde o token retornado. Abra http://127.0.0.1:8888/docs, clique em **Authorize**, informe somente o token e execute GET /health. A resposta esperada é 200, com model_ready=false. POST /v1/systemone retorna 503 model_not_ready. Ctrl+C encerra o servidor.

O banco de tokens fica no diretório de dados da sua conta; --data-dir permite escolher outro destino. Consulte [CLI](docs/cli.md), [API](docs/api.md) e [VPS e HTTPS](docs/deployment.md).

Uso de avaliação autorizado em [BINARY-LICENSE.txt](BINARY-LICENSE.txt). Avisos de terceiros em [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md). O código privado, dados de treino, pesos e credenciais não acompanham este pacote.
